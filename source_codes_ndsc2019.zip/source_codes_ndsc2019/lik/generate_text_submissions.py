import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.pipeline import Pipeline

def mapk(y_allpred, y_actual, k):
    '''Calculates the mean average precision at a threshold of k.'''
    assert len(y_allpred)==len(y_actual), 'Lengths are of pred and actual are different'
    scores=[]
    for jj, y_pred in enumerate(y_allpred):
        if(len(y_pred)==1):
            scores.append(apk([y_pred], [y_actual[jj]], k))
        else: scores.append(apk(y_pred, [y_actual[jj]], k))
    return np.mean(scores)

def apk(y_pred, y_actual, k):
    '''Calculates average precision for a sequence of predictions'''
    score=0
    count=0
    for ii in range(min(k, len(y_pred))):
        if ((y_pred[ii] in y_actual) and (y_pred[ii] not in y_pred[:ii])):
            count+=1
            score=score+count/(ii+1)
    return score/min(len(y_actual), k)

def test_score(tfidf, y, lr, item):
    X_train, X_test, y_train, y_test = train_test_split(tfidf, y, test_size=0.2, random_state=0)
    lr.fit(X_train, y_train)
    allprobs=lr.predict_proba(X_test)
    sortprobs=np.argsort(allprobs, axis=1)[:, ::-1]
    classes=lr.classes_
    y_pred=classes[sortprobs]
    print(item, lr, mapk(y_pred.tolist(), list(y_test), 2))

def make_tfidf(df1, df2, together=False):
    if together:
        trainlen=len(df1)
        series=df1['title'].append(df2['title'])
        vectorizer = CountVectorizer(analyzer = "word", strip_accents=None, tokenizer = None, preprocessor = None, \
                                 stop_words = None, max_features = None, ngram_range=(1,3))
        data_features = vectorizer.fit_transform(series)
        tfidfier = TfidfTransformer()
        all_tfidf = tfidfier.fit_transform(data_features)
        return all_tfidf[:trainlen], all_tfidf[trainlen:]
    else:
        vectorizer = CountVectorizer(analyzer = "word", strip_accents=None, tokenizer = None, preprocessor = None, \
                                 stop_words = None, max_features = None, ngram_range=(1,3))
        train_data_features = vectorizer.fit_transform(df1['title'])
        tfidfier = TfidfTransformer()
        train_tfidf = tfidfier.fit_transform(train_data_features)
        valid_data_features = vectorizer.transform(df2['title'])
        valid_tfidf = tfidfier.transform(valid_data_features)
        return train_tfidf, valid_tfidf


def create_submission_list(trainpath, validpath):
    df_train=pd.read_csv(trainpath)
#     df_train=df_train.fillna(-1)
#     df_train=treatna2(df_train)
    items=[thing for thing in df_train.columns if thing not in ['itemid', 'image_path', 'title']]
    print(items)
    df_valid=pd.read_csv(validpath)
    ids=df_valid['itemid']
    predictions=[]
    for item in items:
        print('training for ', item)
#        lr=LogisticRegression(solver='lbfgs', multi_class='ovr', n_jobs=-1)
#        lr=SVC(kernel='rbf')
#         lr=GaussianNB()
        pipe=Pipeline([('classifier', LogisticRegression())])
#        param_grid=[
#                {'classifier':[LogisticRegression(n_jobs=-1)], 
#                    'classifier__penalty':['l1', 'l2'], 
#                    'classifier__C':[0.1, 0.3, 1, 3, 10],
#                    'classifier__solver':['saga']}, 
#                {'classifier':[RandomForestClassifier(n_jobs=-1)],
#                    'classifier__n_estimators':[100, 200],
#                    'classifier__max_depth':[None, 5],
#                    'classifier__max_features':[None, 'auto']}
#                ]
        param_grid={'penalty':['l1', 'l2'],
                'C':[0.1, 0.3, 0.6, 0.8, 1, 1.2, 1.4, 1.6, 2]}
        lr=RandomizedSearchCV(LogisticRegression(solver='saga', n_jobs=-1), param_distributions=param_grid, n_iter=5, cv=2, verbose=True, n_jobs=-1, refit=True)
        train_tfidf, valid_tfidf = make_tfidf(df_train.dropna(axis=0, subset=[item]), df_valid)
        nanmask=df_train.notna()[item].values
        df_item=df_train.dropna(axis=0, subset=[item])
#        test_score(train_tfidf, df_item[item], lr, item)
        lr.fit(train_tfidf, df_item[item])
        print('You da best!', lr.best_estimator_)
        print('predicting for ', item)
        allprobs=lr.predict_proba(valid_tfidf)
        sortprobs=np.argsort(allprobs, axis=1)[:, ::-1]
        classes=lr.classes_
        y_predicts=classes[sortprobs]
        ids_feature=[str(x)+'_'+item for x in ids]
        tags=[]
        for item in y_predicts:
            tags.append(" ".join(map(str, map(int, item))))
#         tags = [w.replace('-1 ', '') for w in tags]
        predictions.append(pd.DataFrame({'id':ids_feature, 'tagging':tags}))
    return predictions

if __name__ == '__main__':
    predictions_beauty=create_submission_list('./data/beauty_data_info_train_competition.csv', \
                                        './data/beauty_data_info_val_competition.csv')
    predictions_fashion=create_submission_list('./data/fashion_data_info_train_competition.csv', \
                                           './data/fashion_data_info_val_competition.csv')
    predictions_mobile=create_submission_list('./data/mobile_data_info_train_competition.csv', \
                                           './data/mobile_data_info_val_competition.csv')
    all_len=0
    for df in predictions_beauty:
        all_len+=len(df)
    for df in predictions_fashion:
        all_len+=len(df)
    for df in predictions_mobile:
        all_len+=len(df)
    print(all_len)    

    submit_path='./shopee_predictions16.csv'
    predictions_beauty[0].to_csv(submit_path, mode='w', index=False)
    for ii, df in enumerate(predictions_beauty):
        if ii==0: pass
        else:
            df.to_csv(submit_path, mode='a', index=False, header=False)
    for df in predictions_fashion:
        df.to_csv(submit_path, mode='a', index=False, header=False)
    for df in predictions_mobile:
        df.to_csv(submit_path, mode='a', index=False, header=False)
    print('finish3!', submit_path, 'notes: hyperparameter tuning, also tried randomforest')
